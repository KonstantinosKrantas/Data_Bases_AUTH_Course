SELECT post.postID FROM bot JOIN bot_creates_post ON
bot.botID = bot_creates_post.botID JOIN post ON 
post.postID = bot_creates_post.postID where bot.name = 'Jane Smith' and post.likes > 800