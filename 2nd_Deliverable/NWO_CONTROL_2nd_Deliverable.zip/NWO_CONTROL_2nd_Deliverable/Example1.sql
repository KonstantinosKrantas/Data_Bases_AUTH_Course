SELECT contract.ContractID FROM contract JOIN
contract_price on contract_price.parameters = contract.parameters where price >10000000