SELECT SUM(views) AS total_views FROM post JOIN bot_creates_post
ON bot_creates_post.postID = post.postID
JOIN bot ON bot.botID = bot_creates_post.botID;