SELECT botID FROM campaign JOIN campaign_utilizes_bot ON
campaign.campaignID = campaign_utilizes_bot.campaignID  where campaign.campaignID = 2