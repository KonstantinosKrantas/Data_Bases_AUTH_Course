CREATE USER 'employee'@'localhost' IDENTIFIED BY 'strongPassword';

GRANT ALL PRIVILEGES ON bot TO 'employee'@'localhost';
GRANT ALL PRIVILEGES ON contract TO 'employee'@'localhost';
GRANT SELECT ON post TO 'employee'@'localhost';
GRANT SELECT ON feedback TO 'employee'@'localhost';
GRANT SELECT ON client TO 'employee'@'localhost';
GRANT SELECT ON campaign TO 'employee'@'localhost';

CREATE USER 'Client'@'%' IDENTIFIED BY 'password';

GRANT INSERT ON feedback TO 'Client'@'%';
GRANT SELECT ON contract_price TO 'Client'@'%';
GRANT SELECT ON contract TO 'Client'@'%';
GRANT SELECT ON post TO 'Client'@'%';
GRANT SELECT ON campaign TO 'Client'@'%';
GRANT SELECT ON bot TO 'Client'@'%';




