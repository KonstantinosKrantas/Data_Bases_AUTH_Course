This assignment includes the following files:
-- Deliverable 1_corrected.pdf: corrected 1st deliverable of the assignment. May contain small inconsistencies as to the variables, but the models are totally alligned with the model and the database 
-- NWO_CONTROL_DB.mwb: database model in MySQL Workbench format.
-- NWO_CONTROL_DIAGRAM.png: database model diagram as a png file extracted from MySQL Workbench.
-- NWO_Control_dump.sql: SQL script that contains the dump for creating the database (tables, constraints, inserted data, views).
-- Users.sql: SQL script for creating the users of the database and their rights.
-- Example1 to 6: SQL scripts that include queries to the database.
