-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: mydb
-- ------------------------------------------------------
-- Server version	8.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bot`
--

DROP TABLE IF EXISTS `bot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bot` (
  `botID` int unsigned NOT NULL,
  `name` varchar(25) NOT NULL,
  `fb_profile` mediumtext,
  `insta_profile` mediumtext,
  `x_profile` mediumtext,
  `tiktok_profile` mediumtext,
  `reddit_profile` mediumtext,
  PRIMARY KEY (`botID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bot`
--

LOCK TABLES `bot` WRITE;
/*!40000 ALTER TABLE `bot` DISABLE KEYS */;
INSERT INTO `bot` VALUES (1,'Jane Smith','https://shorturl.at/atxy4','https://shorturl.at/kvyKN','https://shorturl.at/kvyKN','https://shorturl.at/kvyKN','https://shorturl.at/kvyKN'),(2,'Thomas Shelby','https://shorturl.at/atxy4','https://shorturl.at/kvyKN','https://shorturl.at/kvyKN','https://shorturl.at/juxK5','https://shorturl.at/rvzF4'),(3,'Joe Diben','https://shorturl.at/atxy4','https://shorturl.at/kvyKN','https://shorturl.at/kvyKN','https://shorturl.at/juxK5','https://shorturl.at/rvzF4'),(4,'Kimun Jong','https://shorturl.at/atxy4','https://shorturl.at/kvyKN','https://shorturl.at/fEFL5','https://shorturl.at/juxK5','https://shorturl.at/rvzF4'),(5,'Axelis Tsirpas','https://shorturl.at/atxy4','https://shorturl.at/kvyKN','https://shorturl.at/fEFL5','https://shorturl.at/juxK5','https://shorturl.at/rvzF4'),(6,'JKF','https://shorturl.at/atxy4','https://shorturl.at/kvyKN','https://shorturl.at/fEFL5','https://shorturl.at/juxK5','https://shorturl.at/rvzF4'),(7,'Elon Husk','https://shorturl.at/atxy4','https://shorturl.at/kvyKN','https://shorturl.at/kvyKN','https://shorturl.at/juxK5','https://shorturl.at/rvzF4'),(8,'Pasok fun','https://shorturl.at/atxy4','https://shorturl.at/kvyKN','https://shorturl.at/fEFL5','https://shorturl.at/juxK5','https://shorturl.at/rvzF4'),(9,'Dictator','https://shorturl.at/atxy4','https://shorturl.at/kvyKN','https://shorturl.at/fEFL5','https://shorturl.at/juxK5','https://shorturl.at/rvzF4'),(10,'Genghis Khan','https://shorturl.at/atxy4','https://shorturl.at/kvyKN','https://shorturl.at/fEFL5','https://shorturl.at/juxK5','https://shorturl.at/rvzF4');
/*!40000 ALTER TABLE `bot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bot_creates_post`
--

DROP TABLE IF EXISTS `bot_creates_post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bot_creates_post` (
  `botID` int unsigned NOT NULL,
  `postID` int unsigned NOT NULL,
  PRIMARY KEY (`botID`,`postID`),
  KEY `fk_Bot_has_Post_Post1_idx` (`postID`),
  KEY `fk_Bot_has_Post_Bot1_idx` (`botID`),
  CONSTRAINT `fk_Bot_has_Post_Bot1` FOREIGN KEY (`botID`) REFERENCES `bot` (`botID`),
  CONSTRAINT `fk_Bot_has_Post_Post1` FOREIGN KEY (`postID`) REFERENCES `post` (`postID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bot_creates_post`
--

LOCK TABLES `bot_creates_post` WRITE;
/*!40000 ALTER TABLE `bot_creates_post` DISABLE KEYS */;
INSERT INTO `bot_creates_post` VALUES (4,2),(9,3),(1,4),(1,5),(3,5),(7,7),(6,8),(9,9),(5,10);
/*!40000 ALTER TABLE `bot_creates_post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campaign`
--

DROP TABLE IF EXISTS `campaign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `campaign` (
  `campaignID` int unsigned NOT NULL,
  `status` enum('Ongoing','Terminated') NOT NULL,
  `Client_User_ID` int unsigned NOT NULL,
  PRIMARY KEY (`campaignID`),
  KEY `fk_Campaign_Client1_idx` (`Client_User_ID`),
  CONSTRAINT `fk_Campaign_Client1` FOREIGN KEY (`Client_User_ID`) REFERENCES `client` (`User_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaign`
--

LOCK TABLES `campaign` WRITE;
/*!40000 ALTER TABLE `campaign` DISABLE KEYS */;
INSERT INTO `campaign` VALUES (1,'Ongoing',10),(2,'Terminated',9),(3,'Ongoing',8),(4,'Ongoing',7),(5,'Ongoing',6),(6,'Terminated',5),(7,'Ongoing',4),(8,'Ongoing',3),(9,'Terminated',2),(10,'Ongoing',1);
/*!40000 ALTER TABLE `campaign` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campaign_utilizes_bot`
--

DROP TABLE IF EXISTS `campaign_utilizes_bot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `campaign_utilizes_bot` (
  `campaignID` int unsigned NOT NULL,
  `botID` int unsigned NOT NULL,
  PRIMARY KEY (`campaignID`,`botID`),
  KEY `fk_Campaign_has_Bot_Bot1_idx` (`botID`),
  KEY `fk_Campaign_has_Bot_Campaign1_idx` (`campaignID`),
  CONSTRAINT `fk_Campaign_has_Bot_Bot1` FOREIGN KEY (`botID`) REFERENCES `bot` (`botID`),
  CONSTRAINT `fk_Campaign_has_Bot_Campaign1` FOREIGN KEY (`campaignID`) REFERENCES `campaign` (`campaignID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaign_utilizes_bot`
--

LOCK TABLES `campaign_utilizes_bot` WRITE;
/*!40000 ALTER TABLE `campaign_utilizes_bot` DISABLE KEYS */;
INSERT INTO `campaign_utilizes_bot` VALUES (10,1),(9,2),(8,3),(7,4),(6,5),(5,6),(4,7),(3,8),(2,9),(1,10);
/*!40000 ALTER TABLE `campaign_utilizes_bot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `client` (
  `Address` varchar(35) DEFAULT NULL,
  `Phone` varchar(20) DEFAULT NULL,
  `IBAN` varchar(35) DEFAULT NULL,
  `User_ID` int unsigned NOT NULL,
  PRIMARY KEY (`User_ID`),
  KEY `fk_Client_User_idx` (`User_ID`),
  CONSTRAINT `fk_Client_User` FOREIGN KEY (`User_ID`) REFERENCES `user` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client`
--

LOCK TABLES `client` WRITE;
/*!40000 ALTER TABLE `client` DISABLE KEYS */;
INSERT INTO `client` VALUES ('address1','6912345678','NL48ABNA9971485915',1),('address2','6913125658','MD8591449124666493579483',2),('address3','6922562235','JO54CXLG4674739948518798534272',3),('address4','6978225632','DE68500105178649566377',4),('address5','6998562466','FR2230003000402919255586F71',5),('address6','6995488996','FR6414508000405375528752H52',6),('address7','6987125462','CY05736694757719347589221662',7),('address8','6978852132','GR0201042746276638852591978',8),('address9','6989665652','GR1501725146591339143339492',9),('address10','6989856213','GR9201418252187729295348654',10);
/*!40000 ALTER TABLE `client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract`
--

DROP TABLE IF EXISTS `contract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contract` (
  `ContractID` int unsigned NOT NULL,
  `status` enum('Pending','Accepted','Rejected') NOT NULL,
  `CampaignID` int unsigned NOT NULL,
  `parameters` varchar(7) NOT NULL,
  `Employee_User_ID` int unsigned NOT NULL,
  PRIMARY KEY (`ContractID`),
  KEY `fk_Contract_Campaign1_idx` (`CampaignID`),
  KEY `fk_Contract_Contract Price1_idx` (`parameters`),
  KEY `fk_Contract_Employee1_idx` (`Employee_User_ID`),
  CONSTRAINT `fk_Contract_Campaign1` FOREIGN KEY (`CampaignID`) REFERENCES `campaign` (`campaignID`),
  CONSTRAINT `fk_Contract_Contract Price1` FOREIGN KEY (`parameters`) REFERENCES `contract_price` (`parameters`),
  CONSTRAINT `fk_Contract_Employee1` FOREIGN KEY (`Employee_User_ID`) REFERENCES `employee` (`User_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract`
--

LOCK TABLES `contract` WRITE;
/*!40000 ALTER TABLE `contract` DISABLE KEYS */;
INSERT INTO `contract` VALUES (1,'Accepted',10,'1000030',11),(2,'Accepted',9,'0000010',12),(3,'Pending',8,'0000120',13),(4,'Pending',7,'1000110',13),(5,'Rejected',6,'1110040',11),(6,'Pending',5,'1000030',13),(7,'Pending',4,'0000010',11),(8,'Accepted',3,'1110040',12),(9,'Accepted',2,'1000110',11),(10,'Accepted',1,'0000120',12);
/*!40000 ALTER TABLE `contract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract_price`
--

DROP TABLE IF EXISTS `contract_price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contract_price` (
  `parameters` varchar(7) NOT NULL,
  `price` float DEFAULT NULL,
  PRIMARY KEY (`parameters`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract_price`
--

LOCK TABLES `contract_price` WRITE;
/*!40000 ALTER TABLE `contract_price` DISABLE KEYS */;
INSERT INTO `contract_price` VALUES ('0000010',21350000),('0000120',10000100),('1000030',100041),('1000110',12541200),('1110040',1865480000);
/*!40000 ALTER TABLE `contract_price` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee` (
  `surname` varchar(25) NOT NULL,
  `name` varchar(25) NOT NULL,
  `SSN` int unsigned NOT NULL,
  `User_ID` int unsigned NOT NULL,
  PRIMARY KEY (`User_ID`),
  CONSTRAINT `fk_Employee_User1` FOREIGN KEY (`User_ID`) REFERENCES `user` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES ('Krantinho','Pedro',10045725,11),('Professor','Themis',10231725,12),('Strikopoulos','Konstantinos',121345725,13);
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_has_bot`
--

DROP TABLE IF EXISTS `employee_has_bot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_has_bot` (
  `Employee_User_ID` int unsigned NOT NULL,
  `botID` int unsigned NOT NULL,
  PRIMARY KEY (`Employee_User_ID`,`botID`),
  KEY `fk_Employee_has_Bot_Bot1_idx` (`botID`),
  KEY `fk_Employee_has_Bot_Employee1_idx` (`Employee_User_ID`),
  CONSTRAINT `fk_Employee_has_Bot_Bot1` FOREIGN KEY (`botID`) REFERENCES `bot` (`botID`),
  CONSTRAINT `fk_Employee_has_Bot_Employee1` FOREIGN KEY (`Employee_User_ID`) REFERENCES `employee` (`User_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_has_bot`
--

LOCK TABLES `employee_has_bot` WRITE;
/*!40000 ALTER TABLE `employee_has_bot` DISABLE KEYS */;
INSERT INTO `employee_has_bot` VALUES (13,1),(12,4),(12,5),(11,6),(11,8),(13,8);
/*!40000 ALTER TABLE `employee_has_bot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `employee_sees_active_clients`
--

DROP TABLE IF EXISTS `employee_sees_active_clients`;
/*!50001 DROP VIEW IF EXISTS `employee_sees_active_clients`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `employee_sees_active_clients` AS SELECT 
 1 AS `ContractID`,
 1 AS `User_ID`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `feedback` (
  `ticket` varchar(20) NOT NULL,
  `date` date DEFAULT NULL,
  `comments` mediumtext,
  `Client_User_ID` int unsigned NOT NULL,
  PRIMARY KEY (`ticket`),
  KEY `fk_Feedback_Client1_idx` (`Client_User_ID`),
  CONSTRAINT `fk_Feedback_Client1` FOREIGN KEY (`Client_User_ID`) REFERENCES `client` (`User_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedback`
--

LOCK TABLES `feedback` WRITE;
/*!40000 ALTER TABLE `feedback` DISABLE KEYS */;
INSERT INTO `feedback` VALUES ('ticket1','2023-12-19','Today is the greatest day I ve ever known',1),('ticket10','1987-06-24','Maradona Es Más Grande Que Pelé',10),('ticket2','2010-08-26','Conquest of paradise',2),('ticket3','1821-03-25','A Dónde Está La Libertad?',3),('ticket4','2001-09-11','Boom boom pow',4),('ticket5','2004-07-04','Because I got high',5),('ticket6','2005-05-21','You are the one',6),('ticket7','2005-09-24','I am blue dabadee',7),('ticket8','2015-01-25','To the window To the wall',8),('ticket9','2015-07-05','Should I stay or should I go',9);
/*!40000 ALTER TABLE `feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post`
--

DROP TABLE IF EXISTS `post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `post` (
  `postID` int unsigned NOT NULL,
  `platform_type` enum('Facebook','Instagram','X','TikTok','Reddit') DEFAULT NULL,
  `shares` int unsigned DEFAULT NULL,
  `views` int unsigned DEFAULT NULL,
  `post_date` date DEFAULT NULL,
  `url` mediumtext,
  `likes` int unsigned DEFAULT NULL,
  `comments` mediumtext,
  PRIMARY KEY (`postID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post`
--

LOCK TABLES `post` WRITE;
/*!40000 ALTER TABLE `post` DISABLE KEYS */;
INSERT INTO `post` VALUES (2,'Facebook',15,3451,'2023-11-18','https://shorturl.at/atxy4',1001,'Wow, dictatorship never felt more free'),(3,'Instagram',5,865,'2023-11-20','https://shorturl.at/rvzF4',176,'Keep going chief'),(4,'Reddit',20,4002,'2023-11-18','https://shorturl.at/fEFL5',764,'WAHTTT? -- Great post! -- Agreed'),(5,'TikTok',100,7088,'2023-11-20','https://shorturl.at/juxK5',981,'Best post I have seen today -- That is so cute'),(6,'X',0,400,'2023-11-19','https://shorturl.at/kvyKN',50,'Cringe dude'),(7,'Facebook',120,6091,'2023-11-20','https://shorturl.at/atxy4',904,'OH CAPTAIN MY CAPTAIN'),(8,'Reddit',6,520,'2023-11-18','https://shorturl.at/fEFL5',146,'lol -- ahahhahahaha '),(9,'Instagram',1200,14807,'2023-11-19','https://shorturl.at/rvzF4',50000,'QUEEEEN -- LETS GOOOO -- GO GET EM'),(10,'TikTok',1290,13004,'2023-11-18','https://shorturl.at/juxK5',5683,'that is my leader -- wouldnt change a word -- I am definitely voting for him');
/*!40000 ALTER TABLE `post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `total_posts_per_day`
--

DROP TABLE IF EXISTS `total_posts_per_day`;
/*!50001 DROP VIEW IF EXISTS `total_posts_per_day`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `total_posts_per_day` AS SELECT 
 1 AS `post_date`,
 1 AS `COUNT(postID)`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `ID` int unsigned NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('user1','password1',1),('user2','password2',2),('user3','password3',3),('user4','password4',4),('user5','password5',5),('user6','password6',6),('user7','password7',7),('user8','password8',8),('user9','password9',9),('user10','password10',10),('user11','password11',11),('user12','password12',12),('user13','password13',13);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `employee_sees_active_clients`
--

/*!50001 DROP VIEW IF EXISTS `employee_sees_active_clients`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `employee_sees_active_clients` AS select `contract`.`ContractID` AS `ContractID`,`client`.`User_ID` AS `User_ID` from ((`campaign` join `client` on((`campaign`.`Client_User_ID` = `client`.`User_ID`))) join `contract` on((`contract`.`CampaignID` = `campaign`.`campaignID`))) where ((`campaign`.`status` = 'Ongoing') and (`contract`.`status` = 'Accepted')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `total_posts_per_day`
--

/*!50001 DROP VIEW IF EXISTS `total_posts_per_day`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `total_posts_per_day` AS select `post`.`post_date` AS `post_date`,count(`post`.`postID`) AS `COUNT(postID)` from `post` group by `post`.`post_date` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-22 18:59:54
